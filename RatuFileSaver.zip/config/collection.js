module.exports={
    FILE_COLLECTION : 'RatuFileBackup',
    USER_COLLECTION : 'user',
    BANNED_COLLECTION :'banned'
}